/*
SQLyog Ultimate v11.24 (32 bit)
MySQL - 5.5.43 : Database - webbase
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `sys_function` */

CREATE TABLE `sys_function` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_function` */

/*Table structure for table `sys_legal_source` */

CREATE TABLE `sys_legal_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '合法源ip',
  `des` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '备注',
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_legal_source` */

insert  into `sys_legal_source`(`id`,`ip`,`des`,`data_status`) values (1,'127.0.0.1','本地访问','ENABLED');

/*Table structure for table `sys_logs` */

CREATE TABLE `sys_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `source_ip` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `action` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `ex_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_logs` */

/*Table structure for table `sys_menu` */

CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `url` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_menu` */

insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (1,0,'首页','/bin/dashboard',1,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (2,0,'系统管理',NULL,100,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (3,0,'软件维护',NULL,110,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (4,3,'角色','/sys/priv/role/list',2,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (5,3,'菜单','/sys/priv/menu/list',3,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (6,3,'功能','/sys/priv/function/list',4,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (7,2,'操作日志','/sys/priv/syslog/list',5,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (8,2,'访问源控制','/sys/priv/legalsource/list',7,'ENABLED');
insert  into `sys_menu`(`id`,`pid`,`name`,`url`,`index`,`data_status`) values (9,2,'用户','/sys/priv/user/list',1,'ENABLED');

/*Table structure for table `sys_method` */

CREATE TABLE `sys_method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `func_id` int(11) DEFAULT NULL,
  `controller` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `method` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `name_cn` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_method` */

/*Table structure for table `sys_role` */

CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_role` */

insert  into `sys_role`(`id`,`name`,`data_status`) values (2,'系统管理','ENABLED');
insert  into `sys_role`(`id`,`name`,`data_status`) values (3,'系统运维','ENABLED');
insert  into `sys_role`(`id`,`name`,`data_status`) values (4,'普通用户','ENABLED');

/*Table structure for table `sys_role_priv` */

CREATE TABLE `sys_role_priv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `res_id` int(11) DEFAULT NULL,
  `res_type` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=297 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_role_priv` */

/*Table structure for table `sys_user` */

CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `name_cn` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `mobile` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `remark` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_user` */

insert  into `sys_user`(`id`,`name`,`name_cn`,`password`,`mail`,`mobile`,`remark`,`data_status`) values (1,'admin','超级管理员','p2z46BfiB1I=',NULL,NULL,NULL,'ENABLED');

/*Table structure for table `sys_user_role` */

CREATE TABLE `sys_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `sys_user_role` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
