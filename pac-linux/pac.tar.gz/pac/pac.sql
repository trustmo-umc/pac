/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : pac

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2019-04-16 15:47:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_function`;
CREATE TABLE `sys_function` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_function
-- ----------------------------
INSERT INTO `sys_function` VALUES ('1', '9', '登录用户维护', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('2', '9', '新增用户', '2', 'DISABLED');
INSERT INTO `sys_function` VALUES ('3', '9', '修改用户', '3', 'DISABLED');
INSERT INTO `sys_function` VALUES ('4', '9', '删除用户', '4', 'DISABLED');
INSERT INTO `sys_function` VALUES ('5', '1', '进入首页页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('6', '15', '进入事件查询页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('7', '13', '进入资源页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('8', '13', '新增资源', '2', 'ENABLED');
INSERT INTO `sys_function` VALUES ('9', '13', '修改资源', '3', 'ENABLED');
INSERT INTO `sys_function` VALUES ('10', '13', '删除资源', '4', 'ENABLED');
INSERT INTO `sys_function` VALUES ('11', '17', '进入账号管理页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('12', '17', '新增账号', '2', 'ENABLED');
INSERT INTO `sys_function` VALUES ('13', '17', '修改账号', '3', 'ENABLED');
INSERT INTO `sys_function` VALUES ('14', '17', '删除账号', '4', 'ENABLED');
INSERT INTO `sys_function` VALUES ('15', '18', '进入密码日志页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('16', '11', '进入适配器页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('17', '11', '新增适配器', '2', 'ENABLED');
INSERT INTO `sys_function` VALUES ('18', '11', '修改适配器', '3', 'ENABLED');
INSERT INTO `sys_function` VALUES ('19', '11', '删除适配器', '4', 'ENABLED');
INSERT INTO `sys_function` VALUES ('20', '12', '进入调度策略库页面', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('21', '12', '新增调度策略库', '2', 'ENABLED');
INSERT INTO `sys_function` VALUES ('22', '12', '修改调度策略库', '3', 'ENABLED');
INSERT INTO `sys_function` VALUES ('23', '12', '删除调度策略库', '4', 'ENABLED');
INSERT INTO `sys_function` VALUES ('24', '19', '接口调用授权管理', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('25', '9', '进入用户页面', '1', 'DISABLED');
INSERT INTO `sys_function` VALUES ('26', '9', '创建用户', '2', 'DISABLED');
INSERT INTO `sys_function` VALUES ('27', '7', '操作日志查询', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('28', '8', '访问源控制', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('29', '4', '角色维护', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('30', '5', '菜单维护', '1', 'ENABLED');
INSERT INTO `sys_function` VALUES ('31', '6', '功能维护', '1', 'ENABLED');

-- ----------------------------
-- Table structure for sys_legal_source
-- ----------------------------
DROP TABLE IF EXISTS `sys_legal_source`;
CREATE TABLE `sys_legal_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '合法源ip',
  `des` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '备注',
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_legal_source
-- ----------------------------
INSERT INTO `sys_legal_source` VALUES ('1', '127.0.0.1', '本地访问', 'DELETED');
INSERT INTO `sys_legal_source` VALUES ('2', '127.0.0.1', '	本地访问', 'ENABLED');

-- ----------------------------
-- Table structure for sys_logs
-- ----------------------------
DROP TABLE IF EXISTS `sys_logs`;
CREATE TABLE `sys_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `source_ip` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `action` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `ex_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1225 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_logs
-- ----------------------------

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `url` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '0', '首页', '/bin/dashboard', '1', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('2', '0', '系统管理', null, '100', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('3', '0', '软件维护', null, '110', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('4', '3', '角色', '/sys/priv/role/list', '2', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('5', '3', '菜单', '/sys/priv/menu/list', '3', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('6', '3', '功能', '/sys/priv/function/list', '4', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('7', '2', '操作日志', '/sys/priv/syslog/list', '5', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('8', '2', '访问源控制', '/sys/priv/legalsource/list', '7', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('9', '2', '用户', '/sys/priv/user/list', '1', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('10', '0', '配置管理', null, '98', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('11', '10', '适配器管理', '/web/adapter/list', '1', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('12', '10', '调度策略库管理', '/web/syscpolicy/list', '2', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('13', '0', '资源管理', '/web/resource/list', '2', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('14', '10', '常量管理', '/web/constant/list', '1', 'DISABLED');
INSERT INTO `sys_menu` VALUES ('15', '0', '事件查询', '/web/auditevent/list', '1', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('17', '20', '账号管理', '/web/account/list', '2', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('18', '20', '账号密码日志', '/web/pwdlog/list', '3', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('19', '10', '接口调用授权', '/web/accesssource/list', '4', 'ENABLED');
INSERT INTO `sys_menu` VALUES ('20', '0', '账号管理', null, '3', 'ENABLED');

-- ----------------------------
-- Table structure for sys_method
-- ----------------------------
DROP TABLE IF EXISTS `sys_method`;
CREATE TABLE `sys_method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `func_id` int(11) DEFAULT NULL,
  `controller` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `method` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `name_cn` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_method
-- ----------------------------
INSERT INTO `sys_method` VALUES ('5', '2', 'sys.privilege.controller.UserController', 'add', '进入新增用户页面');
INSERT INTO `sys_method` VALUES ('6', '2', 'sys.privilege.controller.UserController', 'saveInvoke', '新增用户');
INSERT INTO `sys_method` VALUES ('7', '3', 'sys.privilege.controller.UserController', 'edit', '进入修改用户页面');
INSERT INTO `sys_method` VALUES ('8', '3', 'sys.privilege.controller.UserController', 'updateInvoke', '修改用户');
INSERT INTO `sys_method` VALUES ('9', '3', 'sys.privilege.controller.UserController', 'unlockInvoke', '解锁用户');
INSERT INTO `sys_method` VALUES ('10', '3', 'sys.privilege.controller.UserController', 'statusInvoke', '用户数据状态改变');
INSERT INTO `sys_method` VALUES ('11', '3', 'sys.privilege.controller.UserController', 'refreshPwdInvoke', '重置用户密码');
INSERT INTO `sys_method` VALUES ('12', '4', 'sys.privilege.controller.UserController', 'deleteInvoke', '删除用户');
INSERT INTO `sys_method` VALUES ('23', '8', 'web.resource.controller.ResourceController', 'add', '进入资源维护页面');
INSERT INTO `sys_method` VALUES ('24', '8', 'web.resource.controller.ResourceController', 'listInvokeModel', '查询资源model查询');
INSERT INTO `sys_method` VALUES ('25', '8', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('26', '8', 'web.resource.controller.ResourceController', 'list', '进入资源维护页面');
INSERT INTO `sys_method` VALUES ('27', '8', 'web.resource.controller.ResourceController', 'listInvoke', '资源维护查询');
INSERT INTO `sys_method` VALUES ('28', '8', 'web.resource.controller.ResourceController', 'saveInvoke', '新增资源维护');
INSERT INTO `sys_method` VALUES ('29', '5', 'sys.index.controller.BinController', 'dashboard', '进入首页');
INSERT INTO `sys_method` VALUES ('41', '7', 'web.resource.controller.ResourceController', 'list', '进入资源维护页面');
INSERT INTO `sys_method` VALUES ('42', '7', 'web.resource.controller.ResourceController', 'listInvoke', '资源维护查询');
INSERT INTO `sys_method` VALUES ('43', '7', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('44', '7', 'web.resource.controller.ResourceController', 'dispatchInvoke', '资源调度');
INSERT INTO `sys_method` VALUES ('45', '9', 'web.resource.controller.ResourceController', 'list', '进入资源维护页面');
INSERT INTO `sys_method` VALUES ('46', '9', 'web.resource.controller.ResourceController', 'edit', '进入修改资源维护');
INSERT INTO `sys_method` VALUES ('47', '9', 'web.resource.controller.ResourceController', 'updateInvoke', '修改资源维护');
INSERT INTO `sys_method` VALUES ('48', '9', 'web.resource.controller.ResourceController', 'statusInvoke', '资源维护状态改变');
INSERT INTO `sys_method` VALUES ('49', '9', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('50', '9', 'web.resource.controller.ResourceController', 'listInvoke', '资源维护查询');
INSERT INTO `sys_method` VALUES ('51', '9', 'web.resource.controller.ResourceController', 'saveFenpeiInvoke', '保存分配的调度策略');
INSERT INTO `sys_method` VALUES ('52', '9', 'web.resource.controller.ResourceController', 'fenpeiModel', '分配调度策略模板');
INSERT INTO `sys_method` VALUES ('53', '9', 'web.resource.controller.ResourceController', 'fenpeiModel', '分配调度策略模板');
INSERT INTO `sys_method` VALUES ('54', '9', 'web.resource.controller.ResourceController', 'statusInvoke', '资源维护状态改变');
INSERT INTO `sys_method` VALUES ('55', '10', 'web.resource.controller.ResourceController', 'list', '进入资源维护页面');
INSERT INTO `sys_method` VALUES ('56', '10', 'web.resource.controller.ResourceController', 'listInvokeModel', '查询资源model查询');
INSERT INTO `sys_method` VALUES ('57', '10', 'web.resource.controller.ResourceController', 'listInvoke', '资源维护查询');
INSERT INTO `sys_method` VALUES ('58', '10', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('59', '10', 'web.resource.controller.ResourceController', 'delInvoke', '删除资源维护信息');
INSERT INTO `sys_method` VALUES ('60', '6', 'web.auditevent.controller.AuditEventController', 'list', '进入事件查询页面');
INSERT INTO `sys_method` VALUES ('61', '6', 'web.auditevent.controller.AuditEventController', 'listInvoke', '事件查询查询');
INSERT INTO `sys_method` VALUES ('62', '6', 'web.auditevent.controller.AuditEventController', 'searchExeclogModel', '查看执行日志');
INSERT INTO `sys_method` VALUES ('63', '11', 'web.account.controller.AccountController', 'list', '进入账号维护页面');
INSERT INTO `sys_method` VALUES ('64', '11', 'web.account.controller.AccountController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('65', '11', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('66', '11', 'web.account.controller.AccountController', 'listInvoke', '账号维护查询');
INSERT INTO `sys_method` VALUES ('67', '12', 'web.account.controller.AccountController', 'list', '进入账号维护页面');
INSERT INTO `sys_method` VALUES ('68', '12', 'web.account.controller.AccountController', 'listInvoke', '账号维护查询');
INSERT INTO `sys_method` VALUES ('69', '12', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('70', '12', 'web.account.controller.AccountController', 'savePwdPolicyInvoke', '保存分配的调度策略');
INSERT INTO `sys_method` VALUES ('71', '12', 'web.account.controller.AccountController', 'pwdPolicyModel', '分配密码到期策略模板');
INSERT INTO `sys_method` VALUES ('72', '12', 'web.account.controller.AccountController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('73', '12', 'web.account.controller.AccountController', 'list', '进入账号维护页面');
INSERT INTO `sys_method` VALUES ('74', '12', 'web.account.controller.AccountController', 'add', '进入账号维护页面');
INSERT INTO `sys_method` VALUES ('75', '13', 'web.account.controller.AccountController', 'list', '进入账号维护页面');
INSERT INTO `sys_method` VALUES ('76', '13', 'web.account.controller.AccountController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('77', '13', 'web.account.controller.AccountController', 'savePwdPolicyInvoke', '保存分配的调度策略');
INSERT INTO `sys_method` VALUES ('78', '13', 'web.account.controller.AccountController', 'pwdPolicyModel', '分配密码到期策略模板');
INSERT INTO `sys_method` VALUES ('79', '13', 'web.account.controller.AccountController', 'udpPwdInvoke', '修改密码');
INSERT INTO `sys_method` VALUES ('80', '13', 'web.account.controller.AccountController', 'suspendInvoke', '暂挂账号信息');
INSERT INTO `sys_method` VALUES ('81', '13', 'web.account.controller.AccountController', 'restoreInvoke', '激活账号信息');
INSERT INTO `sys_method` VALUES ('82', '13', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('83', '13', 'web.account.controller.AccountController', 'listInvoke', '账号维护查询');
INSERT INTO `sys_method` VALUES ('84', '13', 'web.account.controller.AccountController', 'edit', '进入修改账号维护');
INSERT INTO `sys_method` VALUES ('85', '13', 'web.account.controller.AccountController', 'updateInvoke', '修改账号维护');
INSERT INTO `sys_method` VALUES ('86', '14', 'web.account.controller.AccountController', 'list', '进入账号维护页面');
INSERT INTO `sys_method` VALUES ('87', '14', 'web.account.controller.AccountController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('88', '14', 'web.account.controller.AccountController', 'listInvoke', '账号维护查询');
INSERT INTO `sys_method` VALUES ('89', '14', 'web.account.controller.AccountController', 'delInvoke', '删除账号信息');
INSERT INTO `sys_method` VALUES ('90', '14', 'web.account.controller.AccountController', 'modalResource', '进入资源查询页面');
INSERT INTO `sys_method` VALUES ('91', '15', 'web.pwdlog.controller.PwdLogController', 'list', '进入密码日志查询页面');
INSERT INTO `sys_method` VALUES ('92', '15', 'web.pwdlog.controller.PwdLogController', 'listInvoke', '密码日志查询');
INSERT INTO `sys_method` VALUES ('93', '16', 'web.adapter.controller.AdapterManagerController', 'list', '进入适配器引擎列表页面');
INSERT INTO `sys_method` VALUES ('94', '16', 'web.adapter.controller.AdapterManagerController', 'listInvoke', '适配器引擎列表查询');
INSERT INTO `sys_method` VALUES ('95', '16', 'web.resource.controller.ResourceController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('96', '16', 'web.account.controller.AccountController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('97', '17', 'web.adapter.controller.AdapterManagerController', 'list', '进入适配器引擎列表页面');
INSERT INTO `sys_method` VALUES ('98', '17', 'web.adapter.controller.AdapterManagerController', 'listInvoke', '适配器引擎列表查询');
INSERT INTO `sys_method` VALUES ('99', '17', 'web.resource.controller.ResourceController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('100', '17', 'web.account.controller.AccountController', 'searchAdapterModel', '根据适配器ID查询适配器资源模板');
INSERT INTO `sys_method` VALUES ('101', '17', 'web.adapter.controller.AdapterManagerController', 'add', '进入新增适配器引擎页面');
INSERT INTO `sys_method` VALUES ('102', '17', 'web.adapter.controller.AdapterManagerController', 'save', '保存适配器引擎');
INSERT INTO `sys_method` VALUES ('103', '18', 'web.adapter.controller.AdapterManagerController', 'list', '进入适配器引擎列表页面');
INSERT INTO `sys_method` VALUES ('104', '18', 'web.adapter.controller.AdapterManagerController', 'listInvoke', '适配器引擎列表查询');
INSERT INTO `sys_method` VALUES ('105', '18', 'web.adapter.controller.AdapterManagerController', 'edit', '进入修改适配器页面');
INSERT INTO `sys_method` VALUES ('106', '18', 'web.adapter.controller.AdapterManagerController', 'update', '更新支撑引擎信息');
INSERT INTO `sys_method` VALUES ('107', '19', 'web.adapter.controller.AdapterManagerController', 'list', '进入适配器引擎列表页面');
INSERT INTO `sys_method` VALUES ('108', '19', 'web.adapter.controller.AdapterManagerController', 'listInvoke', '适配器引擎列表查询');
INSERT INTO `sys_method` VALUES ('109', '19', 'web.adapter.controller.AdapterManagerController', 'delInvoke', '删除引擎信息');
INSERT INTO `sys_method` VALUES ('110', '20', 'web.syncpolicy.controller.SyncPolicyController', 'list', '进入同步策略库列表页面');
INSERT INTO `sys_method` VALUES ('111', '20', 'web.syncpolicy.controller.SyncPolicyController', 'listInvokeType', '根据调度类型分别查询调度策略');
INSERT INTO `sys_method` VALUES ('112', '20', 'web.syncpolicy.controller.SyncPolicyController', 'listInvoke', '同步策略库列表查询');
INSERT INTO `sys_method` VALUES ('113', '20', 'web.syncpolicy.controller.SyncPolicyController', 'statusInvoke', '同步策略库状态改变');
INSERT INTO `sys_method` VALUES ('114', '21', 'web.syncpolicy.controller.SyncPolicyController', 'list', '进入同步策略库列表页面');
INSERT INTO `sys_method` VALUES ('115', '21', 'web.syncpolicy.controller.SyncPolicyController', 'listInvokeType', '根据调度类型分别查询调度策略');
INSERT INTO `sys_method` VALUES ('116', '21', 'web.syncpolicy.controller.SyncPolicyController', 'listInvoke', '同步策略库列表查询');
INSERT INTO `sys_method` VALUES ('117', '21', 'web.syncpolicy.controller.SyncPolicyController', 'add', '进入同步策略库页面');
INSERT INTO `sys_method` VALUES ('118', '21', 'web.syncpolicy.controller.SyncPolicyController', 'saveInvoke', '新增同步策略库');
INSERT INTO `sys_method` VALUES ('119', '21', 'web.account.controller.AccountController', 'pwdPolicyModel', '分配密码到期策略模板');
INSERT INTO `sys_method` VALUES ('120', '21', 'web.account.controller.AccountController', 'savePwdPolicyInvoke', '保存分配的调度策略');
INSERT INTO `sys_method` VALUES ('121', '22', 'web.syncpolicy.controller.SyncPolicyController', 'list', '进入同步策略库列表页面');
INSERT INTO `sys_method` VALUES ('122', '22', 'web.syncpolicy.controller.SyncPolicyController', 'listInvokeType', '根据调度类型分别查询调度策略');
INSERT INTO `sys_method` VALUES ('123', '22', 'web.syncpolicy.controller.SyncPolicyController', 'listInvoke', '同步策略库列表查询');
INSERT INTO `sys_method` VALUES ('124', '22', 'web.syncpolicy.controller.SyncPolicyController', 'edit', '进入修改同步策略库');
INSERT INTO `sys_method` VALUES ('125', '22', 'web.syncpolicy.controller.SyncPolicyController', 'updateInvoke', '修改同步策略库');
INSERT INTO `sys_method` VALUES ('126', '22', 'web.syncpolicy.controller.SyncPolicyController', 'statusInvoke', '同步策略库状态改变');
INSERT INTO `sys_method` VALUES ('127', '22', 'web.account.controller.AccountController', 'pwdPolicyModel', '分配密码到期策略模板');
INSERT INTO `sys_method` VALUES ('128', '22', 'web.account.controller.AccountController', 'savePwdPolicyInvoke', '保存分配的调度策略');
INSERT INTO `sys_method` VALUES ('129', '23', 'web.syncpolicy.controller.SyncPolicyController', 'list', '进入同步策略库列表页面');
INSERT INTO `sys_method` VALUES ('130', '23', 'web.syncpolicy.controller.SyncPolicyController', 'listInvokeType', '根据调度类型分别查询调度策略');
INSERT INTO `sys_method` VALUES ('131', '23', 'web.syncpolicy.controller.SyncPolicyController', 'listInvoke', '同步策略库列表查询');
INSERT INTO `sys_method` VALUES ('132', '23', 'web.syncpolicy.controller.SyncPolicyController', 'delInvoke', '删除同步策略库信息');
INSERT INTO `sys_method` VALUES ('133', '24', 'web.accesssource.controller.AccessSourceController', 'add', '进入接口调用访问源页面');
INSERT INTO `sys_method` VALUES ('134', '24', 'web.accesssource.controller.AccessSourceController', 'list', '进入接口调用访问源页面');
INSERT INTO `sys_method` VALUES ('135', '24', 'web.accesssource.controller.AccessSourceController', 'listInvoke', '接口调用访问源查询');
INSERT INTO `sys_method` VALUES ('136', '24', 'web.accesssource.controller.AccessSourceController', 'saveInvoke', '新增接口调用访问源');
INSERT INTO `sys_method` VALUES ('137', '24', 'web.accesssource.controller.AccessSourceController', 'edit', '进入修改接口调用访问源');
INSERT INTO `sys_method` VALUES ('138', '24', 'web.accesssource.controller.AccessSourceController', 'updateInvoke', '修改同步策略库');
INSERT INTO `sys_method` VALUES ('139', '24', 'web.accesssource.controller.AccessSourceController', 'statusInvoke', '同步策略库状态改变');
INSERT INTO `sys_method` VALUES ('140', '24', 'web.accesssource.controller.AccessSourceController', 'delInvoke', '删除同步策略库信息');
INSERT INTO `sys_method` VALUES ('141', '25', 'sys.privilege.controller.UserController', 'list', '进入用户列表页面');
INSERT INTO `sys_method` VALUES ('142', '25', 'sys.privilege.controller.UserController', 'listInvoke', '用户列表查询');
INSERT INTO `sys_method` VALUES ('143', '26', 'sys.privilege.controller.UserController', 'list', '进入用户列表页面');
INSERT INTO `sys_method` VALUES ('144', '26', 'sys.privilege.controller.UserController', 'listInvoke', '用户列表查询');
INSERT INTO `sys_method` VALUES ('145', '26', 'sys.privilege.controller.UserController', 'add', '进入新增用户页面');
INSERT INTO `sys_method` VALUES ('146', '26', 'sys.privilege.controller.UserController', 'saveInvoke', '新增用户');
INSERT INTO `sys_method` VALUES ('148', '28', 'sys.privilege.controller.LegalSourceController', 'list', '进入访问源列表页面');
INSERT INTO `sys_method` VALUES ('149', '28', 'sys.privilege.controller.LegalSourceController', 'listInvoke', '访问源列表查询');
INSERT INTO `sys_method` VALUES ('150', '28', 'sys.privilege.controller.LegalSourceController', 'add', '进入新增访问源页面');
INSERT INTO `sys_method` VALUES ('151', '28', 'sys.privilege.controller.LegalSourceController', 'statusInvoke', '访问源数据状态改变');
INSERT INTO `sys_method` VALUES ('152', '28', 'sys.privilege.controller.LegalSourceController', 'saveInvoke', '新增访问源');
INSERT INTO `sys_method` VALUES ('160', '30', 'sys.privilege.controller.MenuController', 'menuTreeInvoke', '菜单树形结构查询');
INSERT INTO `sys_method` VALUES ('161', '30', 'sys.privilege.controller.MenuController', 'add', '进入新增菜单页面');
INSERT INTO `sys_method` VALUES ('162', '30', 'sys.privilege.controller.MenuController', 'list', '进入菜单列表页面');
INSERT INTO `sys_method` VALUES ('163', '30', 'sys.privilege.controller.MenuController', 'listInvoke', '菜单列表查询');
INSERT INTO `sys_method` VALUES ('164', '30', 'sys.privilege.controller.MenuController', 'saveInvoke', '新增菜单');
INSERT INTO `sys_method` VALUES ('165', '30', 'sys.privilege.controller.MenuController', 'edit', '进入修改菜单页面');
INSERT INTO `sys_method` VALUES ('166', '30', 'sys.privilege.controller.MenuController', 'updateInvoke', '修改菜单');
INSERT INTO `sys_method` VALUES ('167', '30', 'sys.privilege.controller.MenuController', 'statusInvoke', '菜单数据状态改变');
INSERT INTO `sys_method` VALUES ('168', '31', 'sys.privilege.controller.FunctionController', 'functionTreeInvoke', '功能树形结构查询');
INSERT INTO `sys_method` VALUES ('169', '31', 'sys.privilege.controller.FunctionController', 'add', '进入新增功能页面');
INSERT INTO `sys_method` VALUES ('170', '31', 'sys.privilege.controller.FunctionController', 'list', '进入功能列表页面');
INSERT INTO `sys_method` VALUES ('171', '31', 'sys.privilege.controller.FunctionController', 'listInvoke', '功能列表查询');
INSERT INTO `sys_method` VALUES ('172', '31', 'sys.privilege.controller.FunctionController', 'saveInvoke', '新增功能');
INSERT INTO `sys_method` VALUES ('173', '31', 'sys.privilege.controller.FunctionController', 'edit', '进入修改功能页面');
INSERT INTO `sys_method` VALUES ('174', '31', 'sys.privilege.controller.FunctionController', 'updateInvoke', '修改功能');
INSERT INTO `sys_method` VALUES ('175', '31', 'sys.privilege.controller.FunctionController', 'statusInvoke', '功能数据状态改变');
INSERT INTO `sys_method` VALUES ('176', '1', 'sys.privilege.controller.UserController', 'list', '进入用户列表页面');
INSERT INTO `sys_method` VALUES ('177', '1', 'sys.privilege.controller.UserController', 'listInvoke', '用户列表查询');
INSERT INTO `sys_method` VALUES ('178', '1', 'sys.privilege.controller.UserController', 'add', '进入新增用户页面');
INSERT INTO `sys_method` VALUES ('179', '1', 'sys.privilege.controller.UserController', 'refreshPwdInvoke', '重置用户密码');
INSERT INTO `sys_method` VALUES ('180', '1', 'sys.privilege.controller.UserController', 'saveInvoke', '新增用户');
INSERT INTO `sys_method` VALUES ('181', '1', 'sys.privilege.controller.UserController', 'edit', '进入修改用户页面');
INSERT INTO `sys_method` VALUES ('182', '1', 'sys.privilege.controller.UserController', 'updateInvoke', '修改用户');
INSERT INTO `sys_method` VALUES ('183', '1', 'sys.privilege.controller.UserController', 'unlockInvoke', '解锁用户');
INSERT INTO `sys_method` VALUES ('184', '1', 'sys.privilege.controller.UserController', 'statusInvoke', '用户数据状态改变');
INSERT INTO `sys_method` VALUES ('185', '1', 'sys.privilege.controller.UserController', 'deleteInvoke', '删除用户');
INSERT INTO `sys_method` VALUES ('186', '29', 'sys.privilege.controller.RoleController', 'list', '进入角色列表页面');
INSERT INTO `sys_method` VALUES ('187', '29', 'sys.privilege.controller.RoleController', 'listInvoke', '角色列表查询');
INSERT INTO `sys_method` VALUES ('188', '29', 'sys.privilege.controller.RoleController', 'saveInvoke', '新增角色');
INSERT INTO `sys_method` VALUES ('189', '29', 'sys.privilege.controller.RoleController', 'edit', '进入修改角色页面');
INSERT INTO `sys_method` VALUES ('190', '29', 'sys.privilege.controller.RoleController', 'updateInvoke', '修改角色');
INSERT INTO `sys_method` VALUES ('191', '29', 'sys.privilege.controller.RoleController', 'statusInvoke', '角色数据状态改变');
INSERT INTO `sys_method` VALUES ('192', '29', 'sys.privilege.controller.RoleController', 'add', '进入新增角色页面');
INSERT INTO `sys_method` VALUES ('194', '32', 'sys.privilege.controller.SysLogController', 'list', '进入操作日志页面');
INSERT INTO `sys_method` VALUES ('195', '27', 'sys.privilege.controller.SysLogController', 'list', '进入操作日志页面');
INSERT INTO `sys_method` VALUES ('196', '27', 'sys.privilege.controller.SysLogController', 'listInvoke', '操作日志列表查询');
INSERT INTO `sys_method` VALUES ('197', null, null, null, null);

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('2', '系统管理', 'ENABLED');
INSERT INTO `sys_role` VALUES ('3', '系统运维', 'ENABLED');
INSERT INTO `sys_role` VALUES ('4', '普通用户', 'ENABLED');

-- ----------------------------
-- Table structure for sys_role_priv
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_priv`;
CREATE TABLE `sys_role_priv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `res_id` int(11) DEFAULT NULL,
  `res_type` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_role_priv
-- ----------------------------
INSERT INTO `sys_role_priv` VALUES ('55', '4', '1', 'menu');
INSERT INTO `sys_role_priv` VALUES ('56', '4', '5', 'function');
INSERT INTO `sys_role_priv` VALUES ('57', '4', '15', 'menu');
INSERT INTO `sys_role_priv` VALUES ('58', '4', '6', 'function');
INSERT INTO `sys_role_priv` VALUES ('59', '4', '13', 'menu');
INSERT INTO `sys_role_priv` VALUES ('60', '4', '7', 'function');
INSERT INTO `sys_role_priv` VALUES ('61', '4', '8', 'function');
INSERT INTO `sys_role_priv` VALUES ('62', '4', '9', 'function');
INSERT INTO `sys_role_priv` VALUES ('63', '4', '10', 'function');
INSERT INTO `sys_role_priv` VALUES ('64', '4', '20', 'menu');
INSERT INTO `sys_role_priv` VALUES ('65', '4', '17', 'menu');
INSERT INTO `sys_role_priv` VALUES ('66', '4', '11', 'function');
INSERT INTO `sys_role_priv` VALUES ('67', '4', '12', 'function');
INSERT INTO `sys_role_priv` VALUES ('68', '4', '13', 'function');
INSERT INTO `sys_role_priv` VALUES ('69', '4', '14', 'function');
INSERT INTO `sys_role_priv` VALUES ('70', '4', '18', 'menu');
INSERT INTO `sys_role_priv` VALUES ('71', '4', '15', 'function');
INSERT INTO `sys_role_priv` VALUES ('72', '4', '10', 'menu');
INSERT INTO `sys_role_priv` VALUES ('73', '4', '11', 'menu');
INSERT INTO `sys_role_priv` VALUES ('74', '4', '16', 'function');
INSERT INTO `sys_role_priv` VALUES ('75', '4', '17', 'function');
INSERT INTO `sys_role_priv` VALUES ('76', '4', '18', 'function');
INSERT INTO `sys_role_priv` VALUES ('77', '4', '19', 'function');
INSERT INTO `sys_role_priv` VALUES ('78', '4', '14', 'menu');
INSERT INTO `sys_role_priv` VALUES ('79', '4', '12', 'menu');
INSERT INTO `sys_role_priv` VALUES ('80', '4', '20', 'function');
INSERT INTO `sys_role_priv` VALUES ('81', '4', '21', 'function');
INSERT INTO `sys_role_priv` VALUES ('82', '4', '22', 'function');
INSERT INTO `sys_role_priv` VALUES ('83', '4', '23', 'function');
INSERT INTO `sys_role_priv` VALUES ('84', '4', '19', 'menu');
INSERT INTO `sys_role_priv` VALUES ('85', '4', '24', 'function');
INSERT INTO `sys_role_priv` VALUES ('86', '4', '2', 'menu');
INSERT INTO `sys_role_priv` VALUES ('87', '4', '9', 'menu');
INSERT INTO `sys_role_priv` VALUES ('88', '4', '1', 'function');
INSERT INTO `sys_role_priv` VALUES ('89', '4', '25', 'function');
INSERT INTO `sys_role_priv` VALUES ('90', '4', '2', 'function');
INSERT INTO `sys_role_priv` VALUES ('91', '4', '26', 'function');
INSERT INTO `sys_role_priv` VALUES ('92', '4', '3', 'function');
INSERT INTO `sys_role_priv` VALUES ('93', '4', '4', 'function');
INSERT INTO `sys_role_priv` VALUES ('94', '4', '7', 'menu');
INSERT INTO `sys_role_priv` VALUES ('95', '4', '27', 'function');
INSERT INTO `sys_role_priv` VALUES ('96', '4', '8', 'menu');
INSERT INTO `sys_role_priv` VALUES ('97', '4', '28', 'function');
INSERT INTO `sys_role_priv` VALUES ('98', '4', '3', 'menu');
INSERT INTO `sys_role_priv` VALUES ('99', '4', '4', 'menu');
INSERT INTO `sys_role_priv` VALUES ('100', '4', '29', 'function');
INSERT INTO `sys_role_priv` VALUES ('101', '4', '5', 'menu');
INSERT INTO `sys_role_priv` VALUES ('102', '4', '30', 'function');
INSERT INTO `sys_role_priv` VALUES ('103', '4', '6', 'menu');
INSERT INTO `sys_role_priv` VALUES ('104', '4', '31', 'function');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `name_cn` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `mobile` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `remark` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `data_status` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', 'admin', '超级管理员', 'p2z46BfiB1I=', null, null, null, 'ENABLED');
INSERT INTO `sys_user` VALUES ('6', 'aa', 'aa', 'fiGXlBCl3Cg=', null, null, null, 'DISABLED');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES ('1', '2', '2');
INSERT INTO `sys_user_role` VALUES ('2', '3', '4');
INSERT INTO `sys_user_role` VALUES ('3', '4', '4');
INSERT INTO `sys_user_role` VALUES ('4', '5', '4');
INSERT INTO `sys_user_role` VALUES ('9', '6', '4');
INSERT INTO `sys_user_role` VALUES ('11', '7', '4');

-- ----------------------------
-- Table structure for web_access_source
-- ----------------------------
DROP TABLE IF EXISTS `web_access_source`;
CREATE TABLE `web_access_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `data_status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_access_source
-- ----------------------------
INSERT INTO `web_access_source` VALUES ('1', '127.0.0.1', '本地门户调用', 'ENABLED');

-- ----------------------------
-- Table structure for web_account
-- ----------------------------
DROP TABLE IF EXISTS `web_account`;
CREATE TABLE `web_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resourceid` varchar(20) NOT NULL,
  `ipaddress` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `syncpolicyid` varchar(20) DEFAULT NULL,
  `data` blob NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_account
-- ----------------------------

-- ----------------------------
-- Table structure for web_adapter
-- ----------------------------
DROP TABLE IF EXISTS `web_adapter`;
CREATE TABLE `web_adapter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `jarpath` varchar(200) NOT NULL,
  `jarname` varchar(50) NOT NULL,
  `classpath` varchar(150) NOT NULL,
  `model` blob NOT NULL,
  `createtime` varchar(20) DEFAULT NULL,
  `updatetime` varchar(20) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_adapter
-- ----------------------------

-- ----------------------------
-- Table structure for web_audit_event
-- ----------------------------
DROP TABLE IF EXISTS `web_audit_event`;
CREATE TABLE `web_audit_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resourceid` varchar(20) NOT NULL,
  `resourcename` varchar(60) NOT NULL,
  `action` varchar(50) NOT NULL,
  `accountname` varchar(30) DEFAULT NULL,
  `accountpwd` varchar(50) DEFAULT NULL,
  `accountstatus` varchar(20) DEFAULT NULL,
  `data` blob,
  `committime` varchar(20) NOT NULL,
  `finishtime` varchar(20) DEFAULT NULL,
  `execstatus` varchar(30) DEFAULT NULL,
  `failedreason` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_execstatus` (`execstatus`)
) ENGINE=MyISAM AUTO_INCREMENT=411 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_audit_event
-- ----------------------------

-- ----------------------------
-- Table structure for web_audit_event_execlog
-- ----------------------------
DROP TABLE IF EXISTS `web_audit_event_execlog`;
CREATE TABLE `web_audit_event_execlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auditeventid` varchar(255) NOT NULL,
  `execlog` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=412 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_audit_event_execlog
-- ----------------------------

-- ----------------------------
-- Table structure for web_constant
-- ----------------------------
DROP TABLE IF EXISTS `web_constant`;
CREATE TABLE `web_constant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `data_status` varchar(20) NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_constant
-- ----------------------------
INSERT INTO `web_constant` VALUES ('14', '13', '网络设备', 'ENABLED', '接管网络设备资源');
INSERT INTO `web_constant` VALUES ('15', '13', '主机', 'ENABLED', '主机');
INSERT INTO `web_constant` VALUES ('13', '0', '设备类型', 'ENABLED', '接入资源设备的类型(网络设备,主机设备等等)');
INSERT INTO `web_constant` VALUES ('7', '0', '调度类型', 'ENABLED', '主要用来管理调度策略库里面的调度类型');
INSERT INTO `web_constant` VALUES ('8', '7', '年调度', 'ENABLED', '每年调度一次');
INSERT INTO `web_constant` VALUES ('9', '7', '月调度', 'ENABLED', '每月调度一次');
INSERT INTO `web_constant` VALUES ('10', '7', '周调度', 'ENABLED', '使用于每个星期调度一次');
INSERT INTO `web_constant` VALUES ('11', '7', '日调度', 'ENABLED', '每天某个时间调度一次');
INSERT INTO `web_constant` VALUES ('12', '7', '定期调度', 'ENABLED', '主要适用于年/月/周/日 4种调度都不能满足的额外调度情况');
INSERT INTO `web_constant` VALUES ('16', '15', 'Redhat', 'ENABLED', 'Redhat');
INSERT INTO `web_constant` VALUES ('17', '15', 'Suse', 'ENABLED', null);

-- ----------------------------
-- Table structure for web_pwd_log
-- ----------------------------
DROP TABLE IF EXISTS `web_pwd_log`;
CREATE TABLE `web_pwd_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resourceid` varchar(20) NOT NULL,
  `resourcename` varchar(100) NOT NULL,
  `accountname` varchar(100) NOT NULL,
  `accountpwd` varchar(100) NOT NULL,
  `time` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_pwd_log
-- ----------------------------

-- ----------------------------
-- Table structure for web_resource
-- ----------------------------
DROP TABLE IF EXISTS `web_resource`;
CREATE TABLE `web_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ipaddress` varchar(20) NOT NULL,
  `createsource` varchar(50) NOT NULL,
  `syncpolicyid` varchar(20) DEFAULT NULL,
  `adapterid` varchar(20) NOT NULL,
  `data` blob NOT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `createtime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_resource
-- ----------------------------

-- ----------------------------
-- Table structure for web_resource_lose
-- ----------------------------
DROP TABLE IF EXISTS `web_resource_lose`;
CREATE TABLE `web_resource_lose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resourceid` varchar(20) NOT NULL,
  `actiontime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_resource_lose
-- ----------------------------

-- ----------------------------
-- Table structure for web_sync_policy
-- ----------------------------
DROP TABLE IF EXISTS `web_sync_policy`;
CREATE TABLE `web_sync_policy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `date` varchar(50) NOT NULL,
  `exectime` varchar(20) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `data_status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of web_sync_policy
-- ----------------------------
INSERT INTO `web_sync_policy` VALUES ('23', '测试-月', '9', '17/01:00', '2019-04-17 01:00:00', null, 'ENABLED');
INSERT INTO `web_sync_policy` VALUES ('24', '测试-周', '10', '4/04:00', '2019-04-18 04:00:00', '33', 'ENABLED');
INSERT INTO `web_sync_policy` VALUES ('25', '测试-周', '10', '2/05:00', '2019-04-23 05:00:00', null, 'ENABLED');
INSERT INTO `web_sync_policy` VALUES ('26', '测试-日', '11', '05:00', '2019-04-16 05:00:00', '呃呃呃', 'ENABLED');
INSERT INTO `web_sync_policy` VALUES ('27', '测试-定期', '12', '75', '2017-12-31 15:47:43', '333', 'ENABLED');
INSERT INTO `web_sync_policy` VALUES ('22', '测试-年', '8', '2017-10-05/05:00', '2019-10-05 05:00:00', null, 'ENABLED');
