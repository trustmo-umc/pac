#!/bin/bash
basepath=$(cd `dirname $0`; pwd)
pacpath=pac
function echo_green {
    echo -e "\033[32m$1\033[0m"
}

function seturl {
	echo_green "======请设置配置中心-数据库url,使用默认配置请直接回车==========="
	echo_green "输入格式：jdbc:mysql://127.0.0.1:3306/$pacpath?characterEncoding=utf8"
	
	echo -n "-->" 
	read answer
	
	if [ "$answer" != "" ]; then
		sed -i "s#^jdbc.url=.*#jdbc.url=$answer#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
	else
		echo_green "使用默认配置"。
	fi
}

function setuser {
	echo_green "======请设置配置中心-数据库用户名,使用默认配置请直接回车==========="
	
	echo -n  "-->" 
	read answer
	
	if [ "$answer" != "" ]; then
		sed -i "s#^jdbc.user=.*#jdbc.user=$answer#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
	else
		echo_green "使用默认配置"。
	fi
}

function setpwd {
	echo_green "======请设置配置中心-数据库密码,使用默认配置请直接回车==========="

	echo -n  "-->" 
	read answer

	if [ "$answer" != "" ]; then
		sed -i "s#^jdbc.pwd=.*#jdbc.pwd=$answer#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
	else
		echo_green "使用默认配置"。
	fi
}

function setapdir {
	echo_green "======请设置配置中心-适配器存放目录,使用默认配置请直接回车==========="
	echo_green "默认当前目录:$basepath/adapterdirs"
	echo -n  "-->" 
	read answer
	
	if [ "$answer" != "" ]; then
		if [ -d $answer ]; then
			sed -i "s#^uploaddir=.*#uploaddir=$answer#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
		else
			echo_green "输入的路径不是一个有效目录,使用默认目录:$basepath/adapterdirs"
			sed -i "s#^uploaddir=.*#uploaddir=$basepath/adapterdirs#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
		fi
	else
		echo_green "使用默认配置"。
		sed -i "s#^uploaddir=.*#uploaddir=$basepath/uploaddir#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
	fi
	
	if [ ! -d $basepath/adapterdirs ]; then
				mkdir $basepath/adapterdirs
	fi
}

function settempdir {
	echo_green "======请设置配置中心-适配器临时存放目录,使用默认配置请直接回车==========="
	echo_green "默认当前目录:$basepath/tempuploaddir"
	echo -n  "-->" 
	read answer
	
	if [ "$answer" != "" ]; then
		if [ -d $answer ]; then
			sed -i "s#^tempuploaddir=.*#tempuploaddir=$answer#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
		else
			echo_green "输入的路径不是一个有效目录,使用默认目录:$basepath/tempuploaddir"
			sed -i "s#^tempuploaddir=.*#tempuploaddir=$basepath/tempuploaddir#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
		fi
	else
		echo_green "使用默认配置"。
		sed -i "s#^tempuploaddir=.*#tempuploaddir=$basepath/tempuploaddir#g" $basepath/$pacpath/WEB-INF/classes/constant.properties
	fi
	
	if [ ! -d $basepath/tempuploaddir ]; then
				mkdir $basepath/tempuploaddir
	fi
}
echo "###############################################################"
echo "请输入你需要的操作类型"
echo "1:检测JDK版本信息"
echo "2:检测MYSQL版本信息"
echo "3:配置特权账号管控平台基础信息"
echo "4:部署特权账号管控平台到Tomcat"
echo "5:退出"
echo "###############################################################"
echo -n "-->"
read userinput
if [ "$userinput" == "1" ] ; then
				echo "当前JDK版本信息"
        java -version
elif [ "$userinput" == "2" ] ; then
				echo "当前MYSQL版本信息"
        mysql -V
elif [ "$userinput" == "3" ] ; then
       echo "配置特权账号管控平台基础信息!!!"
       seturl
       setuser
       setpwd
       setapdir
       settempdir

elif [ "$userinput" == "4" ] ; then
        echo "指定tomcat服务器目录位置"
        echo -n  "-->" 
        read tomcatdir
        if [ -d "$tomcatdir" ] ; then
                echo "开始复制特权账号管控平台到$tomcatdir/webapps/"
                if [ ! -d $tomcatdir/webapps ]; then
									mkdir $tomcatdir/webapps
								fi
								if [ ! -d $tomcatdir/webapps/pac ]; then
									rm -fr $tomcatdir/webapps/pac
								fi
		if [ ! -d $tomcatdir/webapps/pac ]; then									rm -fr $tomcatdir/webapps/pac								      fi
                cp -R pac $tomcatdir/webapps/
        else
                echo "$tomcatdir 目录不存在,部署失败"
                exit 0
        fi
elif [ "$userinput" == "5" ] ; then
        echo "退出!!!"
else
        echo "输入错误,引导程序退出!!!"
        exit 0
fi

